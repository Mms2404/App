const String GEMINI_API = "AQ.Ab8RN6L6ccuZuspC8tZNKI5qbhesa7kl9Z-vBTTvIa18cJ0LHw";
const String YOUTUBE_API = "AIzaSyDxdxrQzxt5qVswReW37j7H6kyNMwOuYlM";

const String RAZORPAY_KEY_ID= "rzp_test_SvWHM0jIujuAHd";






