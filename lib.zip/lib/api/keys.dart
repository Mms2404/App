const String GEMINI_API = "AIzaSyDiBgZ_-PcVDeBG5AywLcq4Jc73vOqu3xo";
const String YOUTUBE_API = "AIzaSyACBspziU6ELoj0I2iBQcXAg8VMQJXuUBA";

const String RAZORPAY_KEY_ID= "rzp_test_SvWHM0jIujuAHd";






